(() => {
    "use strict";

    // ============================================================
    // CONFIGURAÇÃO
    // ============================================================

    const GUILD_ID = "246815328103825409";
    const CHANNEL_ID = "947606292376207490";

    const CHANNEL_URL =
        `https://discord.com/channels/${GUILD_ID}/${CHANNEL_ID}`;

    const DISCORD_MESSAGE_URL =
        `https://discord.com/channels/${GUILD_ID}/${CHANNEL_ID}`;

    const MARKER_TEXT = "Suggestions are now open.";

    const PAGE_LIMIT = 100;

    const CATEGORY_IMAGES = {
        "All": "https://static.wikia.nocookie.net/transformice/images/e/ef/Shop-emoji20024.png",

        "Fur": "https://static.wikia.nocookie.net/transformice/images/3/3d/Shop-fur2.png",
        "Head": "https://static.wikia.nocookie.net/transformice/images/4/40/Shop-head1.png",
        "Ears": "https://static.wikia.nocookie.net/transformice/images/0/0f/Shop-ears9.png",
        "Eyes": "https://static.wikia.nocookie.net/transformice/images/7/76/Shop-eyes7.png",
        "Mouth": "https://static.wikia.nocookie.net/transformice/images/4/4c/Shop-mouth29.png",
        "Neck": "https://static.wikia.nocookie.net/transformice/images/3/34/Shop-neck1.png",
        "Tail": "https://static.wikia.nocookie.net/transformice/images/1/16/Shop-tail1.png",
        "Hair Style": "https://static.wikia.nocookie.net/transformice/images/d/db/Shop-hair1.png",
        "Contact Lenses": "https://static.wikia.nocookie.net/transformice/images/1/12/Shop-contacts1.png",
        "Tattoo": "https://static.wikia.nocookie.net/transformice/images/0/08/Shop-tattoo1.png",
        "Hands": "https://static.wikia.nocookie.net/transformice/images/c/c6/Shop-hands2.png",

        "Small Box": "https://static.wikia.nocookie.net/transformice/images/4/41/Shop-smallbox49.png",
        "Large Box": "https://static.wikia.nocookie.net/transformice/images/f/f4/Shop-largebox58.png",
        "Short Plank": "https://static.wikia.nocookie.net/transformice/images/5/58/Shop-smallplank36.png",
        "Long Plank": "https://static.wikia.nocookie.net/transformice/images/0/01/Shop-largeplank48.png",
        "Cannonball": "https://static.wikia.nocookie.net/transformice/images/8/8a/Shop-cannonball66.png",
        "Balloon": "https://static.wikia.nocookie.net/transformice/images/a/a8/Shop-balloon5.png",
        "Anvil": "https://static.wikia.nocookie.net/transformice/images/8/81/Shop-anvil45.png",
        "Ball": "https://static.wikia.nocookie.net/transformice/images/6/6f/Shop-ball69.png",
        "Trampoline": "https://static.wikia.nocookie.net/transformice/images/4/49/Shop-trampoline30.png"
    };


    // ============================================================
    // ESTADO
    // ============================================================

    let items = [];
    let currentCategory = "All";
    let searchTerm = "";
    let sortColumn = "count";
    let sortDirection = "desc";

    let modalHost = null;
    let modalShadow = null;

    let initializedButton = false;
    let observer = null;

    let loadingData = false;


    // ============================================================
    // UTILITÁRIOS
    // ============================================================

    function isCorrectChannel() {
        return window.location.pathname ===
            `/channels/${GUILD_ID}/${CHANNEL_ID}`;
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    function normalizeText(value) {
        return String(value ?? "")
            .replace(/\s+/g, " ")
            .trim();
    }

    function escapeHTML(value) {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function safeNumber(value) {
        const n = Number(value);
        return Number.isFinite(n) ? n : 0;
    }
	
	function loadToken(username) {
	  return new Promise((resolve) => {
		chrome.storage.local.get(["tokens"], (result) => {
		  const tokens = result.tokens || {};
		  resolve(tokens[username] || null);
		});
	  });
	}

	async function getToken(username) {
	  const token = await loadToken(username);
	  return token;
	}


    // ============================================================
    // COMUNICAÇÃO COM BACKGROUND
    // ============================================================

    /*
     * O background deve responder:
     *
     * {
     *   ok: true,
     *   messages: [...]
     * }
     *
     * ou
     *
     * {
     *   ok: false,
     *   error: "..."
     * }
     *
     * Para paginação:
     *
     * { type: "GET_SALE_MESSAGES", channelId, limit, before }
     */

    async function requestMessagesPage(before = null) {
        const userToken = await getToken("ratufufu");
		if (before != null) {
			const res = await fetch(`https://discord.com/api/v9/channels/947606292376207490/messages?before=${before}&limit=100`, {
			  "headers": {
				"accept": "*/*",
				"accept-language": "pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
				"authorization": userToken.toString(),
				"cache-control": "no-cache",
				"pragma": "no-cache",
				"priority": "u=1, i",
				"x-debug-options": "bugReporterEnabled",
				"x-discord-locale": "pt-BR",
				"x-discord-timezone": "America/Sao_Paulo",
				"x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6InB0LUJSIiwiaGFzX2NsaWVudF9tb2RzIjpmYWxzZSwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE1NC4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xNTQuMC4wLjAiLCJicm93c2VyX3ZlcnNpb24iOiIxNTQuMC4wLjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6NjIyODA1LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsLCJjbGllbnRfbGF1bmNoX2lkIjoiY2ZlYjBiMDctNDE3OS00OWFmLWEzZjctMzQxZDNhOTIyNWRlIiwibGF1bmNoX3NpZ25hdHVyZSI6IjRmNTI2NzZmLTc1ODMtNDRlNi05YTQ2LTA3YTk5YTFkOTU3YyIsImNsaWVudF9oZWFydGJlYXRfc2Vzc2lvbl9pZCI6ImU5YjYxZDZlLTY2NGMtNDk0Zi1iYWI2LWZlZTRhMzZjNjg4YyIsImNsaWVudF9hcHBfc3RhdGUiOiJmb2N1c2VkIn0="
			  },
			  "referrer": "https://discord.com/channels/246815328103825409/947606292376207490",
			  "body": null,
			  "method": "GET",
			  "mode": "cors",
			  "credentials": "include"
			});
		} else {
			const res = await fetch("https://discord.com/api/v9/channels/947606292376207490/messages?limit=100", {
			  "headers": {
				"accept": "*/*",
				"accept-language": "pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
				"authorization": userToken.toString(),
				"cache-control": "no-cache",
				"pragma": "no-cache",
				"priority": "u=1, i",
				"x-debug-options": "bugReporterEnabled",
				"x-discord-locale": "pt-BR",
				"x-discord-timezone": "America/Sao_Paulo",
				"x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6InB0LUJSIiwiaGFzX2NsaWVudF9tb2RzIjpmYWxzZSwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE1NC4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xNTQuMC4wLjAiLCJicm93c2VyX3ZlcnNpb24iOiIxNTQuMC4wLjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6NjIyODA1LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsLCJjbGllbnRfbGF1bmNoX2lkIjoiYTM1ZWQ3Y2UtMzZjMy00YWNmLWJkYjUtZDMzZWMwYzlmYzA1IiwibGF1bmNoX3NpZ25hdHVyZSI6ImQwM2RlNGM4LWYzZTAtNDMwOS04NjQ2LTdmYjkxMmM3MjBlZSIsImNsaWVudF9oZWFydGJlYXRfc2Vzc2lvbl9pZCI6ImQwMDhhMjQyLTVmMjUtNGI4ZC04NWFmLWU3MjNiYzc0MTExNiIsImNsaWVudF9hcHBfc3RhdGUiOiJ1bmZvY3VzZWQifQ=="
			  },
			  "referrer": "https://discord.com/channels/246815328103825409/947606292376207490",
			  "body": null,
			  "method": "GET",
			  "mode": "cors",
			  "credentials": "include"
			});
		}
		const result = await res.json();
		return result
    }


    // ============================================================
    // OBTÉM TODAS AS MENSAGENS ATÉ O MARCADOR
    // ============================================================

   async function loadAllMessages() {

    const parsedItems = [];

    let before = null;
    let finished = false;

    const MAX_PAGES = 1000;
    let page = 0;

    while (!finished && page < MAX_PAGES) {

        page++;

        // Já retorna diretamente o JSON:
        // [
        //   { message... },
        //   { message... }
        // ]
        const messages =
            await requestMessagesPage(before);

        if (
            !Array.isArray(messages) ||
            messages.length === 0
        ) {
            break;
        }

        // Percorre exatamente na ordem recebida
        for (const message of messages) {

            const content =
                normalizeText(message?.content);

            // Encontrou o início da fase.
            // Não adiciona essa mensagem e interrompe.
            if (
                content.includes(
                    MARKER_TEXT
                )
            ) {
                finished = true;
                break;
            }

            const item =
                parseMessage(message);

            if (item) {
                parsedItems.push(item);
            }
        }

        if (finished) {
            break;
        }

        /*
         * O último elemento do JSON é
         * utilizado como cursor da próxima página.
         */
        const lastMessage =
            messages[messages.length - 1];

        if (!lastMessage?.id) {
            break;
        }

        before =
            lastMessage.id;

        /*
         * Se retornou menos de 100,
         * não há necessidade de continuar.
         */
        if (
            messages.length < PAGE_LIMIT
        ) {
            break;
        }

        await sleep(50);
    }

    return parsedItems;
}

    // ============================================================
    // PARSE DE UMA MENSAGEM
    // ============================================================

    function parseMessage(message) {

        if (!message || !Array.isArray(message.embeds)) {
            return null;
        }

        const embed =
            message.embeds.find(e => e?.type === "rich") ||
            message.embeds[0];

        if (!embed) {
            return null;
        }

        const title =
            normalizeText(embed.title);

        if (!title) {
            return null;
        }

        let category = "";
        let categoryID = null;
        let itemID = null;

        const fields =
            Array.isArray(embed.fields)
                ? embed.fields
                : [];

        for (const field of fields) {

            const fieldName =
                normalizeText(field?.name);

            const fieldValue =
                normalizeText(field?.value);

            if (fieldName.toLowerCase() === "category") {
                category = fieldValue;
            }

            if (fieldName.toLowerCase() === "item id") {

                /*
                 * Exemplo:
                 *
                 * "22,296"
                 *
                 * categoria = 22
                 * item       = 296
                 */

                const parts =
                    fieldValue.split(",");

                if (parts.length >= 2) {

                    const parsedCategoryID =
                        parseInt(
                            parts[0].trim(),
                            10
                        );

                    const parsedItemID =
                        parseInt(
                            parts[1].trim(),
                            10
                        );

                    if (Number.isFinite(parsedCategoryID)) {
                        categoryID = parsedCategoryID;
                    }

                    if (Number.isFinite(parsedItemID)) {
                        itemID = parsedItemID;
                    }
                }
            }
        }

        /*
         * Imagem do thumbnail.
         */

        const imageURL =
            embed.thumbnail?.url || "";

        /*
         * Normalmente o reaction desejado será "sale_star".
         *
         * Primeiro tenta encontrar esse emoji.
         * Se não existir, utiliza a primeira reação.
         */

        let count = 0;

        if (Array.isArray(message.reactions)) {

            const saleReaction =
                message.reactions.find(
                    reaction =>
                        reaction?.emoji?.name === "sale_star"
                );

            const reaction =
                saleReaction ||
                message.reactions[0];

            count =
                safeNumber(reaction?.count);
        }

        if (!message.id) {
            return null;
        }

        return {
            title,
            category,
            categoryID,
            itemID,
            img: imageURL,
            count,
            messageID: String(message.id)
        };
    }


    // ============================================================
    // BOTÃO DO DISCORD
    // ============================================================

    function createSaleButton() {

        if (document.getElementById(
            "tfm-sale-extension-button"
        )) {
            initializedButton = true;
            return;
        }

        const containers =
            document.querySelectorAll(
                'div[class*="sansAttachButton_"]'
            );

        for (const sansAttach of containers) {

            const buttons =
                sansAttach.querySelector(
                    'div[class*="buttons_"]'
                );

            if (!buttons) {
                continue;
            }

            /*
             * Evita inserir duas vezes.
             */

            if (
                buttons.querySelector(
                    "#tfm-sale-extension-button"
                )
            ) {
                initializedButton = true;
                return;
            }

            const button =
                document.createElement("div");

            button.id =
                "tfm-sale-extension-button";

            button.className =
                "tfm-sale-button-wrapper";

            button.setAttribute(
                "aria-label",
                "Transformice Sale"
            );

            button.setAttribute(
                "aria-haspopup",
                "dialog"
            );

            button.setAttribute(
                "aria-disabled",
                "false"
            );

            button.setAttribute(
                "tabindex",
                "0"
            );

            button.setAttribute(
                "role",
                "button"
            );

            const buttonInner =
                document.createElement("div");

            buttonInner.className =
                "tfm-sale-button-inner";

            const image =
                document.createElement("img");

            image.className =
                "tfm-sale-button-image";

            image.src =
                chrome.runtime.getURL(
                    "sale.png"
                );

            image.alt =
                "Sale";

            image.draggable = false;

            buttonInner.appendChild(image);
            button.appendChild(buttonInner);

            /*
             * Primeiro slot.
             */

            buttons.insertBefore(
                button,
                buttons.firstElementChild
            );

            /*
             * Hover:
             *
             * sale.png -> sale.gif
             */

            button.addEventListener(
                "mouseenter",
                () => {
                    image.src =
                        chrome.runtime.getURL(
                            "sale.gif"
                        );
                }
            );

            button.addEventListener(
                "mouseleave",
                () => {
                    image.src =
                        chrome.runtime.getURL(
                            "sale.png"
                        );
                }
            );

            button.addEventListener(
                "click",
                openModal
            );

            button.addEventListener(
                "keydown",
                event => {

                    if (
                        event.key === "Enter" ||
                        event.key === " "
                    ) {
                        event.preventDefault();
                        openModal();
                    }
                }
            );

            initializedButton = true;

            return;
        }

        initializedButton = false;
    }


    // ============================================================
    // ESTILOS DO BOTÃO
    // ============================================================

    function injectButtonStyles() {

        if (
            document.getElementById(
                "tfm-sale-button-style"
            )
        ) {
            return;
        }

        const style =
            document.createElement("style");

        style.id =
            "tfm-sale-button-style";

        style.textContent = `
            #tfm-sale-extension-button {
                width: 32px;
                height: 32px;

                margin: 0 4px;

                display: flex;
                align-items: center;
                justify-content: center;

                cursor: pointer;

                color: var(--interactive-normal);

                border-radius: 4px;

                transition:
                    background-color 120ms ease,
                    color 120ms ease,
                    transform 120ms ease;
            }

            #tfm-sale-extension-button:hover {
                background: var(--background-modifier-hover);
                color: var(--interactive-hover);
            }

            #tfm-sale-extension-button:active {
                transform: scale(0.92);
            }

            .tfm-sale-button-inner {
                width: 20px;
                height: 20px;

                display: flex;
                align-items: center;
                justify-content: center;
            }

            .tfm-sale-button-image {
                display: block;

                width: 20px;
                height: 20px;

                object-fit: contain;

                pointer-events: none;

                user-select: none;
            }
        `;

        document.head.appendChild(style);
    }


    // ============================================================
    // MODAL
    // ============================================================

    function createModal() {

        if (modalHost) {
            return;
        }

        modalHost =
            document.createElement("div");

        modalHost.id =
            "tfm-sale-modal-host";

        document.body.appendChild(
            modalHost
        );

        modalShadow =
            modalHost.attachShadow({
                mode: "open"
            });

        const wrapper =
            document.createElement("div");

        wrapper.className =
            "tfm-modal-wrapper";

        wrapper.innerHTML = `
            <div class="tfm-overlay"></div>

            <section
                class="tfm-modal"
                role="dialog"
                aria-modal="true"
                aria-labelledby="tfm-modal-title"
            >

                <header class="tfm-header">

                    <div class="tfm-header-left">

                        <div class="tfm-brand-icon">
                            <img
                                src="${chrome.runtime.getURL("sale.png")}"
                                alt=""
                            >
                        </div>

                        <div>
                            <div
                                id="tfm-modal-title"
                                class="tfm-title"
                            >
                                Transformice Sale
                            </div>

                            <div class="tfm-subtitle">
                                Itens da fase atual
                            </div>
                        </div>

                    </div>

                    <button
                        class="tfm-close"
                        type="button"
                        aria-label="Fechar"
                    >
                        ×
                    </button>

                </header>

                <div class="tfm-body">

                    <div class="tfm-toolbar">

                        <div
                            class="tfm-categories"
                        ></div>

                        <div class="tfm-search-wrapper">

                            <svg
                                viewBox="0 0 24 24"
                                aria-hidden="true"
                                class="tfm-search-icon"
                            >
                                <path
                                    d="M10.5 4a6.5 6.5 0 1 0 4.03 11.6l4.43 4.43 1.42-1.42-4.43-4.43A6.5 6.5 0 0 0 10.5 4Zm0 2a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9Z"
                                />
                            </svg>

                            <input
                                class="tfm-search"
                                type="search"
                                placeholder="Pesquisar item..."
                                autocomplete="off"
                                spellcheck="false"
                            />

                            <span
                                class="tfm-result-count"
                            >
                                0
                            </span>

                        </div>

                    </div>

                    <div class="tfm-content">

                        <div
                            class="tfm-loading"
                        >
                            <div class="tfm-spinner"></div>

                            <div>
                                Carregando itens...
                            </div>
                        </div>

                        <div
                            class="tfm-table-container"
                        ></div>

                    </div>

                </div>

                <footer class="tfm-footer">

                    <div class="tfm-footer-left">
                        <span class="tfm-status-dot"></span>
                        <span>Sale Database</span>
                    </div>

                    <div class="tfm-footer-right">
                        <span class="tfm-footer-count">
                            0 itens
                        </span>
                    </div>

                </footer>

            </section>
        `;

        modalShadow.appendChild(
            createModalStyles()
        );

        modalShadow.appendChild(
            wrapper
        );

        const overlay =
            wrapper.querySelector(
                ".tfm-overlay"
            );

        const close =
            wrapper.querySelector(
                ".tfm-close"
            );

        const search =
            wrapper.querySelector(
                ".tfm-search"
            );

        overlay.addEventListener(
            "click",
            closeModal
        );

        close.addEventListener(
            "click",
            closeModal
        );

        search.addEventListener(
            "input",
            event => {
                searchTerm =
                    event.target.value
                        .trim()
                        .toLowerCase();

                renderTable();
            }
        );

        document.addEventListener(
            "keydown",
            modalEscapeHandler
        );
    }


    function createModalStyles() {

        const style =
            document.createElement("style");

        style.textContent = `

            :host {
                all: initial;
            }

            * {
                box-sizing: border-box;
            }

            .tfm-modal-wrapper {
                position: fixed;
                inset: 0;

                z-index: 2147483647;

                display: flex;
                align-items: center;
                justify-content: center;

                font-family:
                    Inter,
                    -apple-system,
                    BlinkMacSystemFont,
                    "Segoe UI",
                    sans-serif;

                color: #f2f3f5;
            }

            .tfm-overlay {
                position: absolute;
                inset: 0;

                background:
                    rgba(5, 7, 10, .72);

                backdrop-filter:
                    blur(8px);
            }

            .tfm-modal {
                position: relative;

                width: min(
                    calc(100vw - 48px),
                    1180px
                );

                height: min(
                    calc(100vh - 48px),
                    820px
                );

                min-height: 540px;

                display: flex;
                flex-direction: column;

                overflow: hidden;

                border:
                    1px solid
                    rgba(255,255,255,.08);

                border-radius: 16px;

                background:
                    linear-gradient(
                        145deg,
                        #17191d 0%,
                        #111317 55%,
                        #0d0f12 100%
                    );

                box-shadow:
                    0 30px 100px
                    rgba(0,0,0,.65),
                    0 0 0 1px
                    rgba(255,255,255,.025);

                animation:
                    tfm-modal-enter
                    180ms ease-out;
            }

            @keyframes tfm-modal-enter {
                from {
                    opacity: 0;
                    transform:
                        translateY(8px)
                        scale(.985);
                }

                to {
                    opacity: 1;
                    transform:
                        translateY(0)
                        scale(1);
                }
            }

            .tfm-header {
                height: 76px;

                display: flex;
                align-items: center;
                justify-content: space-between;

                padding:
                    0 22px;

                border-bottom:
                    1px solid
                    rgba(255,255,255,.07);

                background:
                    rgba(255,255,255,.015);
            }

            .tfm-header-left {
                display: flex;
                align-items: center;

                gap: 13px;
            }

            .tfm-brand-icon {
                width: 40px;
                height: 40px;

                display: flex;
                align-items: center;
                justify-content: center;

                border-radius: 11px;

                background:
                    linear-gradient(
                        145deg,
                        rgba(88,101,242,.28),
                        rgba(88,101,242,.08)
                    );

                border:
                    1px solid
                    rgba(88,101,242,.22);

                box-shadow:
                    inset 0 1px
                    rgba(255,255,255,.05);
            }

            .tfm-brand-icon img {
                width: 24px;
                height: 24px;

                object-fit: contain;
            }

            .tfm-title {
                font-size: 18px;
                font-weight: 700;

                letter-spacing: -.2px;
            }

            .tfm-subtitle {
                margin-top: 3px;

                font-size: 12px;

                color: #8d929b;
            }

            .tfm-close {
                width: 34px;
                height: 34px;

                border: 0;
                border-radius: 8px;

                background:
                    transparent;

                color: #9499a2;

                font-size: 25px;
                line-height: 1;

                cursor: pointer;

                transition:
                    background 120ms,
                    color 120ms,
                    transform 120ms;
            }

            .tfm-close:hover {
                background:
                    rgba(255,255,255,.07);

                color: #fff;
            }

            .tfm-close:active {
                transform: scale(.92);
            }

            .tfm-body {
                flex: 1;

                min-height: 0;

                display: flex;
                flex-direction: column;

                padding: 18px 20px 0;
            }

            .tfm-toolbar {
                display: flex;

                gap: 14px;

                align-items: center;

                margin-bottom: 15px;
            }

            .tfm-categories {
                flex: 1;

                min-width: 0;

                display: flex;

                align-items: center;

                gap: 7px;

                overflow-x: auto;

                padding-bottom: 2px;

                scrollbar-width: thin;
                scrollbar-color:
                    rgba(255,255,255,.12)
                    transparent;
            }

            .tfm-category {
                flex: 0 0 auto;

                height: 38px;

                display: flex;
                align-items: center;

                gap: 8px;

                padding:
                    0 11px;

                border-radius: 9px;

                border:
                    1px solid
                    rgba(255,255,255,.055);

                background:
                    rgba(255,255,255,.025);

                color: #afb3ba;

                cursor: pointer;

                user-select: none;

                font-size: 12px;
                font-weight: 600;

                transition:
                    background 130ms,
                    border-color 130ms,
                    color 130ms,
                    transform 130ms;
            }

            .tfm-category:hover {
                color: #f0f1f3;

                background:
                    rgba(255,255,255,.065);
            }

            .tfm-category:active {
                transform:
                    translateY(1px);
            }

            .tfm-category.active {
                color: #fff;

                border-color:
                    rgba(88,101,242,.44);

                background:
                    linear-gradient(
                        135deg,
                        rgba(88,101,242,.24),
                        rgba(88,101,242,.11)
                    );

                box-shadow:
                    inset 0 0 0 1px
                    rgba(88,101,242,.07);
            }

            .tfm-category img {
                width: 25px;
                height: 25px;

                object-fit: contain;
            }

            .tfm-search-wrapper {
                position: relative;

                flex: 0 0 265px;

                height: 38px;
            }

            .tfm-search {
                width: 100%;
                height: 38px;

                border:
                    1px solid
                    rgba(255,255,255,.07);

                border-radius: 9px;

                outline: none;

                background:
                    rgba(0,0,0,.22);

                color: #f2f3f5;

                padding:
                    0 63px 0 37px;

                font-size: 13px;

                transition:
                    border-color 130ms,
                    background 130ms,
                    box-shadow 130ms;
            }

            .tfm-search::placeholder {
                color: #686d76;
            }

            .tfm-search:focus {
                border-color:
                    rgba(88,101,242,.55);

                background:
                    rgba(0,0,0,.3);

                box-shadow:
                    0 0 0 3px
                    rgba(88,101,242,.10);
            }

            .tfm-search-icon {
                position: absolute;

                left: 11px;
                top: 50%;

                width: 18px;
                height: 18px;

                transform:
                    translateY(-50%);

                fill: #737983;

                pointer-events: none;
            }

            .tfm-result-count {
                position: absolute;

                right: 10px;
                top: 50%;

                min-width: 22px;
                height: 22px;

                display: flex;
                align-items: center;
                justify-content: center;

                transform:
                    translateY(-50%);

                padding: 0 6px;

                border-radius: 6px;

                background:
                    rgba(255,255,255,.055);

                color: #9196a0;

                font-size: 11px;
                font-weight: 700;
            }

            .tfm-content {
                flex: 1;

                min-height: 0;

                overflow: hidden;
            }

            .tfm-loading {
                height: 100%;

                display: flex;
                flex-direction: column;

                align-items: center;
                justify-content: center;

                gap: 13px;

                color: #858b95;

                font-size: 13px;
            }

            .tfm-spinner {
                width: 28px;
                height: 28px;

                border-radius: 50%;

                border:
                    3px solid
                    rgba(255,255,255,.07);

                border-top-color:
                    #5865f2;

                animation:
                    tfm-spin 800ms linear infinite;
            }

            @keyframes tfm-spin {
                to {
                    transform:
                        rotate(360deg);
                }
            }

            .tfm-table-container {
                width: 100%;
                height: 100%;

                overflow: auto;

                border:
                    1px solid
                    rgba(255,255,255,.055);

                border-radius: 11px;

                background:
                    rgba(0,0,0,.12);

                scrollbar-width: thin;
                scrollbar-color:
                    rgba(255,255,255,.13)
                    transparent;
            }

            .tfm-table {
                width: 100%;

                border-collapse:
                    separate;

                border-spacing: 0;

                table-layout: fixed;
            }

            .tfm-table th {
                position: sticky;
                top: 0;

                z-index: 4;

                height: 42px;

                padding:
                    0 13px;

                text-align: left;

                border-bottom:
                    1px solid
                    rgba(255,255,255,.065);

                background:
                    #16191d;

                color: #848a94;

                font-size: 11px;
                font-weight: 700;

                text-transform: uppercase;

                letter-spacing:
                    .065em;

                user-select: none;
            }

            .tfm-table th.sortable {
                cursor: pointer;
            }

            .tfm-table th.sortable:hover {
                color: #c5c8cd;
            }

            .tfm-sort-indicator {
                display: inline-block;

                margin-left: 6px;

                opacity: .25;

                font-size: 11px;
            }

            .tfm-sort-indicator.active {
                opacity: 1;

                color: #7883ff;
            }

            .tfm-table td {
                height: 62px;

                padding:
                    7px 13px;

                border-bottom:
                    1px solid
                    rgba(255,255,255,.035);

                color: #d8dbe0;

                font-size: 12px;
            }

            .tfm-table tbody tr {
                transition:
                    background 100ms;
            }

            .tfm-table tbody tr:hover {
                background:
                    rgba(255,255,255,.032);
            }

            .tfm-table tbody tr:last-child td {
                border-bottom: 0;
            }

            .tfm-col-image {
                width: 90px;
            }

            .tfm-col-id {
                width: 120px;
            }

            .tfm-col-title {
                width: auto;
            }

            .tfm-col-count {
                width: 110px;
            }

            .tfm-col-message {
                width: 120px;
            }

            .tfm-item-image {
                width: 48px;
                height: 48px;

                object-fit: contain;

                display: block;

                margin: auto;

                filter:
                    drop-shadow(
                        0 5px 9px
                        rgba(0,0,0,.35)
                    );
            }

            .tfm-id {
                font-family:
                    ui-monospace,
                    SFMono-Regular,
                    Menlo,
                    Monaco,
                    Consolas,
                    monospace;

                font-size: 12px;

                color: #aeb4bd;
            }

            .tfm-item-title {
                overflow: hidden;

                text-overflow: ellipsis;
                white-space: nowrap;

                font-weight: 600;

                color: #e5e7ea;
            }

            .tfm-category-small {
                display: block;

                margin-top: 4px;

                color: #6d737d;

                font-size: 10px;
            }

            .tfm-count {
                display: inline-flex;

                align-items: center;

                justify-content: center;

                min-width: 40px;

                height: 26px;

                padding:
                    0 8px;

                border-radius: 7px;

                background:
                    rgba(255,255,255,.045);

                color: #d7dae0;

                font-weight: 700;
            }

            .tfm-message-link {
                display: inline-flex;

                align-items: center;

                justify-content: center;

                height: 27px;

                padding:
                    0 9px;

                border-radius: 7px;

                text-decoration: none;

                background:
                    rgba(88,101,242,.12);

                border:
                    1px solid
                    rgba(88,101,242,.17);

                color: #929cff;

                font-size: 11px;
                font-weight: 700;

                transition:
                    background 120ms,
                    border-color 120ms,
                    color 120ms;
            }

            .tfm-message-link:hover {
                background:
                    rgba(88,101,242,.23);

                border-color:
                    rgba(88,101,242,.35);

                color: #b6bdff;
            }

            .tfm-empty {
                height: 100%;

                display: flex;
                flex-direction: column;

                align-items: center;
                justify-content: center;

                gap: 8px;

                color: #777d87;
            }

            .tfm-empty-title {
                color: #afb4bc;

                font-size: 14px;
                font-weight: 700;
            }

            .tfm-empty-text {
                font-size: 12px;
            }

            .tfm-footer {
                height: 44px;

                display: flex;
                align-items: center;
                justify-content: space-between;

                padding:
                    0 20px;

                border-top:
                    1px solid
                    rgba(255,255,255,.055);

                color: #686e78;

                font-size: 11px;
            }

            .tfm-footer-left {
                display: flex;
                align-items: center;

                gap: 7px;
            }

            .tfm-status-dot {
                width: 7px;
                height: 7px;

                border-radius: 50%;

                background: #3ba55d;

                box-shadow:
                    0 0 8px
                    rgba(59,165,93,.45);
            }

            .tfm-footer-right {
                color: #777d87;
            }
        `;

        return style;
    }


    // ============================================================
    // CATEGORIAS
    // ============================================================

    function renderCategories() {

        if (!modalShadow) {
            return;
        }

        const container =
            modalShadow.querySelector(
                ".tfm-categories"
            );

        if (!container) {
            return;
        }

        container.innerHTML = "";

        for (const category of Object.keys(
            CATEGORY_IMAGES
        )) {

            const button =
                document.createElement("button");

            button.type = "button";

            button.className =
                "tfm-category" +
                (
                    category === currentCategory
                        ? " active"
                        : ""
                );

            const image =
                document.createElement("img");

            image.src =
                CATEGORY_IMAGES[category];

            image.alt = category;

            const label =
                document.createElement("span");

            label.textContent =
                category;

            button.appendChild(image);
            button.appendChild(label);

            button.addEventListener(
                "click",
                () => {

                    currentCategory =
                        category;

                    renderCategories();
                    renderTable();
                }
            );

            container.appendChild(button);
        }
    }


    // ============================================================
    // FILTRO E ORDENAÇÃO
    // ============================================================

    function getVisibleItems() {

        let result =
            items.filter(item => {

                if (
                    currentCategory !== "All" &&
                    item.category !== currentCategory
                ) {
                    return false;
                }

                if (!searchTerm) {
                    return true;
                }

                const search =
                    [
                        item.title,
                        item.category,
                        item.itemID,
                        item.categoryID,
                        item.count
                    ]
                        .join(" ")
                        .toLowerCase();

                return search.includes(
                    searchTerm
                );
            });

        result.sort(
            (a, b) => {

                let comparison = 0;

                switch (sortColumn) {

                    case "itemID":
                        comparison =
                            safeNumber(a.itemID) -
                            safeNumber(b.itemID);
                        break;

                    case "title":
                        comparison =
                            String(a.title)
                                .localeCompare(
                                    String(b.title),
                                    "pt-BR",
                                    {
                                        numeric: true,
                                        sensitivity: "base"
                                    }
                                );
                        break;

                    case "count":
                        comparison =
                            safeNumber(a.count) -
                            safeNumber(b.count);
                        break;
                }

                return sortDirection === "asc"
                    ? comparison
                    : -comparison;
            }
        );

        return result;
    }


    function toggleSort(column) {

        if (sortColumn === column) {
            sortDirection =
                sortDirection === "asc"
                    ? "desc"
                    : "asc";
        } else {
            sortColumn = column;

            /*
             * Ao trocar de coluna:
             *
             * count começa decrescente
             * demais começam crescente
             */

            sortDirection =
                column === "count"
                    ? "desc"
                    : "asc";
        }

        renderTable();
    }


    function renderSortIndicator(column) {

        if (sortColumn !== column) {
            return "";
        }

        return `
            <span class="tfm-sort-indicator active">
                ${sortDirection === "asc" ? "▲" : "▼"}
            </span>
        `;
    }


    // ============================================================
    // TABELA
    // ============================================================

    function renderTable() {

        if (!modalShadow) {
            return;
        }

        const container =
            modalShadow.querySelector(
                ".tfm-table-container"
            );

        const loading =
            modalShadow.querySelector(
                ".tfm-loading"
            );

        if (!container) {
            return;
        }

        const visible =
            getVisibleItems();

        const resultCount =
            modalShadow.querySelector(
                ".tfm-result-count"
            );

        const footerCount =
            modalShadow.querySelector(
                ".tfm-footer-count"
            );

        if (resultCount) {
            resultCount.textContent =
                String(visible.length);
        }

        if (footerCount) {
            footerCount.textContent =
                `${visible.length} ${
                    visible.length === 1
                        ? "item"
                        : "itens"
                }`;
        }

        if (loading) {
            loading.style.display = "none";
        }

        if (visible.length === 0) {

            container.innerHTML = `
                <div class="tfm-empty">
                    <div class="tfm-empty-title">
                        Nenhum item encontrado
                    </div>

                    <div class="tfm-empty-text">
                        Tente outra categoria ou termo de pesquisa.
                    </div>
                </div>
            `;

            return;
        }

        const table =
            document.createElement("table");

        table.className =
            "tfm-table";

        table.innerHTML = `
            <thead>
                <tr>

                    <th class="tfm-col-image">
                        IMG
                    </th>

                    <th
                        class="sortable tfm-col-id"
                        data-sort="itemID"
                    >
                        Item ID
                        ${renderSortIndicator("itemID")}
                    </th>

                    <th
                        class="sortable tfm-col-title"
                        data-sort="title"
                    >
                        Title
                        ${renderSortIndicator("title")}
                    </th>

                    <th
                        class="sortable tfm-col-count"
                        data-sort="count"
                    >
                        Count
                        ${renderSortIndicator("count")}
                    </th>

                    <th class="tfm-col-message">
                        Mensagem
                    </th>

                </tr>
            </thead>

            <tbody></tbody>
        `;

        const tbody =
            table.querySelector("tbody");

        for (const item of visible) {

            const tr =
                document.createElement("tr");

            tr.innerHTML = `
                <td>
                    ${
                        item.img
                            ? `
                                <img
                                    class="tfm-item-image"
                                    src="${escapeHTML(item.img)}"
                                    alt=""
                                    loading="lazy"
                                >
                            `
                            : `
                                <div style="
                                    width:48px;
                                    height:48px;
                                    margin:auto;
                                "></div>
                            `
                    }
                </td>

                <td>
                    <span class="tfm-id">
                        ${escapeHTML(
                            item.itemID ?? "-"
                        )}
                    </span>
                </td>

                <td>
                    <div class="tfm-item-title">
                        ${escapeHTML(item.title)}
                    </div>

                    <span class="tfm-category-small">
                        ${escapeHTML(
                            item.category || "Unknown"
                        )}
                    </span>
                </td>

                <td>
                    <span class="tfm-count">
                        ${escapeHTML(item.count)}
                    </span>
                </td>

                <td>
                    ${
                        item.messageID
                            ? `
                                <a
                                    class="tfm-message-link"
                                    href="${DISCORD_MESSAGE_URL}/${encodeURIComponent(item.messageID)}"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Mensagem
                                </a>
                            `
                            : "-"
                    }
                </td>
            `;

            tbody.appendChild(tr);
        }

        container.innerHTML = "";

        container.appendChild(
            table
        );

        for (const th of table.querySelectorAll(
            "th[data-sort]"
        )) {

            th.addEventListener(
                "click",
                () => {
                    toggleSort(
                        th.dataset.sort
                    );
                }
            );
        }
    }


    // ============================================================
    // MODAL
    // ============================================================

    async function openModal() {

        if (!isCorrectChannel()) {
            return;
        }

        createModal();

        modalHost.style.display =
            "block";

        document.body.style.overflow =
            "hidden";

        currentCategory = "All";
        searchTerm = "";
        sortColumn = "count";
        sortDirection = "desc";

        const search =
            modalShadow.querySelector(
                ".tfm-search"
            );

        if (search) {
            search.value = "";
        }

        renderCategories();

        const container =
            modalShadow.querySelector(
                ".tfm-table-container"
            );

        const loading =
            modalShadow.querySelector(
                ".tfm-loading"
            );

        if (container) {
            container.innerHTML = "";
        }

        if (loading) {
            loading.style.display =
                "flex";
        }

        if (loading) {
            loading.querySelector(
                "div:last-child"
            ).textContent =
                "Carregando itens...";
        }

        if (loadingData) {
            return;
        }

        loadingData = true;

        try {

            items =
                await loadAllMessages();

            renderTable();

        } catch (error) {

            console.error(
                "[Transformice Sale]",
                error
            );

            if (loading) {

                loading.style.display =
                    "flex";

                loading.innerHTML = `
                    <div
                        style="
                            font-size: 30px;
                            line-height: 1;
                        "
                    >
                        !
                    </div>

                    <div>
                        Não foi possível carregar os itens.
                    </div>

                    <div
                        style="
                            max-width:420px;
                            text-align:center;
                            color:#666c75;
                            font-size:11px;
                        "
                    >
                        ${escapeHTML(
                            error.message
                        )}
                    </div>
                `;
            }

        } finally {
            loadingData = false;
        }
    }


    function closeModal() {

        if (!modalHost) {
            return;
        }

        modalHost.style.display =
            "none";

        document.body.style.overflow =
            "";
    }


    function modalEscapeHandler(event) {

        if (
            event.key === "Escape" &&
            modalHost &&
            modalHost.style.display !== "none"
        ) {
            closeModal();
        }
    }


    // ============================================================
    // MONITORAMENTO DO DISCORD
    // ============================================================

    function checkPage() {

        if (!isCorrectChannel()) {

            const existing =
                document.getElementById(
                    "tfm-sale-extension-button"
                );

            if (existing) {
                existing.remove();
            }

            initializedButton = false;

            closeModal();

            return;
        }

        injectButtonStyles();

        createSaleButton();
    }


    function startObserver() {

        if (observer) {
            return;
        }

        observer =
            new MutationObserver(() => {

                /*
                 * Evita executar dezenas de vezes
                 * durante a mesma atualização do Discord.
                 */

                if (!window.__tfmSaleCheckQueued) {

                    window.__tfmSaleCheckQueued =
                        true;

                    requestAnimationFrame(() => {

                        window.__tfmSaleCheckQueued =
                            false;

                        checkPage();
                    });
                }
            });

        observer.observe(
            document.body,
            {
                childList: true,
                subtree: true
            }
        );
    }


    // ============================================================
    // HISTÓRICO DE NAVEGAÇÃO
    // ============================================================

    function patchHistory() {

        const originalPushState =
            history.pushState;

        history.pushState =
            function (...args) {

                const result =
                    originalPushState.apply(
                        this,
                        args
                    );

                window.dispatchEvent(
                    new Event(
                        "tfm-location-change"
                    )
                );

                return result;
            };

        const originalReplaceState =
            history.replaceState;

        history.replaceState =
            function (...args) {

                const result =
                    originalReplaceState.apply(
                        this,
                        args
                    );

                window.dispatchEvent(
                    new Event(
                        "tfm-location-change"
                    )
                );

                return result;
            };

        window.addEventListener(
            "popstate",
            () => {
                checkPage();
            }
        );

        window.addEventListener(
            "tfm-location-change",
            () => {

                setTimeout(
                    checkPage,
                    100
                );
            }
        );
    }


    // ============================================================
    // INICIALIZAÇÃO
    // ============================================================

    function init() {

        injectButtonStyles();

        patchHistory();

        startObserver();

        checkPage();
    }


    if (
        document.readyState ===
        "loading"
    ) {
        document.addEventListener(
            "DOMContentLoaded",
            init,
            { once: true }
        );
    } else {
        init();
    }

})();