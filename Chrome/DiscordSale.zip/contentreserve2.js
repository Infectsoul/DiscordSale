/* Discord Sale - content.js */
(() => {
  'use strict';

  const GUILD_ID = '246815328103825409';
  const CHANNEL_ID = '947606292376207490';
  const STOP_TEXT = 'Suggestions are now open.';
  const MESSAGE_URL = `https://discord.com/channels/${GUILD_ID}/${CHANNEL_ID}/`;

  const BTN_ATTR = 'data-sale-btn';
  const URL_PNG = chrome.runtime.getURL('image/sale.png');
  const URL_GIF = chrome.runtime.getURL('image/sale.gif');
  const URL_GIF2 = chrome.runtime.getURL('image/sale2.gif');

  // Categorias (ordem de exibição) e ícones
  const CATEGORIES = [
    { name: 'All', group: 'main', img: chrome.runtime.getURL('image/All.png') },
    { name: 'Fur', group: 'main', img: chrome.runtime.getURL('image/Fur.png') },
    { name: 'Head', group: 'main', img: chrome.runtime.getURL('image/Head.png') },
    { name: 'Ears', group: 'main', img: chrome.runtime.getURL('image/Ears.png') },
    { name: 'Eyes', group: 'main', img: chrome.runtime.getURL('image/Eyes.png') },
    { name: 'Mouth', group: 'main', img: chrome.runtime.getURL('image/Mouth.png') },
    { name: 'Neck', group: 'main', img: chrome.runtime.getURL('image/Neck.png') },
    { name: 'Tail', group: 'main', img: chrome.runtime.getURL('image/Tail.png') },
    { name: 'Hair Style', group: 'main', img: chrome.runtime.getURL('image/Hair_Style.png') },
    { name: 'Contact Lenses', group: 'main', img: chrome.runtime.getURL('image/Contact_Lenses.png') },
    { name: 'Tattoo', group: 'main', img: chrome.runtime.getURL('image/Tattoo.png') },
    { name: 'Hands', group: 'main', img: chrome.runtime.getURL('image/Hands.png') },

    { name: 'Small Box', group: 'objects', img: chrome.runtime.getURL('image/Small_Box.png') },
    { name: 'Large Box', group: 'objects', img: chrome.runtime.getURL('image/Large_Box.png') },
    { name: 'Short Plank', group: 'objects', img: chrome.runtime.getURL('image/Short_Plank.png') },
    { name: 'Long Plank', group: 'objects', img: chrome.runtime.getURL('image/Long_Plank.png') },
    { name: 'Cannonball', group: 'objects', img: chrome.runtime.getURL('image/Cannonball.png') },
    { name: 'Balloon', group: 'objects', img: chrome.runtime.getURL('image/Balloon.png') },
    { name: 'Anvil', group: 'objects', img: chrome.runtime.getURL('image/Anvil.png') },
    { name: 'Ball', group: 'objects', img: chrome.runtime.getURL('image/Ball.png') },
    { name: 'Trampoline', group: 'objects', img: chrome.runtime.getURL('image/Trampoline.png') },
  ];

  /* ------------------------------------------------------------------ *
   *  API
   * ------------------------------------------------------------------ */
   
    function getHeaders() {
	  return new Promise((resolve) => {
		chrome.storage.local.get(["requestHeaders"], (result) => {
		  resolve(result.requestHeaders || {});
		});
	  });
	}

	async function sendFetch(url, method, referrer="https://discord.com/channels/246815328103825409/947606292376207490") {
		const headers = await getHeaders();

		return await fetch(url, {
			headers,
			referrer,
			body: null,
			method,
			mode: "cors",
			credentials: "include"
		});
	}

  // Deixe vazia: você implementa a requisição (deve retornar o array do .json()).
   async function requestMessages(before = null) {
		let res;
		if (before != null) {
			res = await sendFetch(`https://discord.com/api/v9/channels/947606292376207490/messages?before=${before}&limit=100`, "GET");
		} else {
			res = await sendFetch("https://discord.com/api/v9/channels/947606292376207490/messages?limit=100", "GET");
		}
		return await res.json();
    }



  /* ------------------------------------------------------------------ *
   *  Leitura das mensagens
   * ------------------------------------------------------------------ */

  function parseMessage(msg) {
    const embed = msg && Array.isArray(msg.embeds) ? msg.embeds[0] : null;
    if (!embed) return null;

    const fields = Array.isArray(embed.fields) ? embed.fields : [];
    const getField = (name) => {
      const f = fields.find((x) => String(x.name || '').trim().toLowerCase() === name);
      return f ? String(f.value ?? '').trim() : '';
    };

    const category = getField('category');
    const rawId = getField('item id');
    if (!rawId) return null;

    // "22,296" -> categoryID = 22, itemID = 296
    const [catPart, itemPart] = rawId.split(',').map((s) => s.trim());
    const categoryID = parseInt(catPart, 10);
    const itemID = parseInt(itemPart, 10);

    const reactions = Array.isArray(msg.reactions) ? msg.reactions : [];
    const reaction = reactions.find((r) => r.emoji && r.emoji.name === 'sale_star') || reactions[0];

    return {
      title: embed.title || '',
      category,
      categoryID: Number.isNaN(categoryID) ? 0 : categoryID,
      itemID: Number.isNaN(itemID) ? 0 : itemID,
      img: embed.thumbnail ? embed.thumbnail.proxy_url : '',
      count: reaction ? Number(reaction.count) || 0 : 0,
	  voted: reaction ? reaction.me === true : false,
      messageID: msg.id,
    };
  }

  // Lê de cima para baixo; se não achar a mensagem de parada, pagina com o último id.
  async function fetchAllItems(onProgress) {
    const items = [];
    const seenMessages = new Set();
    const usedCursors = new Set();
    let before = null;

    while (true) {
      const messages = await requestMessages(before);
      if (!Array.isArray(messages) || messages.length === 0) break;

      let reachedStop = false;

      for (const msg of messages) {
        if (typeof msg.content === 'string' && msg.content.includes(STOP_TEXT)) {
          reachedStop = true;
          break;
        }
        const item = parseMessage(msg);
        if (item && !seenMessages.has(item.messageID)) {
          seenMessages.add(item.messageID);
          items.push(item);
        }
      }

      if (onProgress) onProgress(items.length);
      if (reachedStop) break;

      const lastId = messages[messages.length - 1].id;
      if (!lastId || usedCursors.has(lastId)) break;
      usedCursors.add(lastId);
      before = lastId;
    }

    return items;
  }

  /* ------------------------------------------------------------------ *
   *  Modal
   * ------------------------------------------------------------------ */

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; }

    .overlay {
      position: fixed; inset: 0; z-index: 2147483000;
      display: flex; align-items: center; justify-content: center;
      background: rgba(4, 5, 8, .72);
      backdrop-filter: blur(6px);
      font-family: "gg sans", "Inter", "Segoe UI", system-ui, sans-serif;
      color: #e8e9ef;
      animation: fade .16s ease-out;
    }
    @keyframes fade { from { opacity: 0 } to { opacity: 1 } }
    @keyframes rise { from { transform: translateY(10px) scale(.985); opacity: 0 } to { transform: none; opacity: 1 } }

    .panel {
      --ink: #0d0e12;
      --panel: #14151b;
      --raised: #1a1c24;
      --line: #262833;
      --muted: #8b8fa3;
      --amber: #ffa005;
      --blurple: #5865f2;
      width: min(1180px, 94vw); height: min(780px, 90vh);
      display: grid; grid-template-columns: 236px 1fr;
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 16px;
      box-shadow: 0 30px 90px rgba(0,0,0,.65), 0 0 0 1px rgba(255,255,255,.02) inset;
      overflow: hidden;
      animation: rise .2s cubic-bezier(.2,.8,.2,1);
    }

    /* Sidebar */
    .side {
      display: flex; flex-direction: column; min-height: 0;
      background: linear-gradient(180deg, #111218, #0d0e12);
      border-right: 1px solid var(--line);
    }
    .brand { display: flex; align-items: center; gap: 10px; padding: 18px 16px 14px; }
    .brand img { width: 26px; height: 26px; object-fit: contain; }
    .brand b { font-size: 16px; letter-spacing: .2px; }
    .brand span { display: block; font-size: 11.5px; color: var(--muted); margin-top: 1px; }

    .cats { flex: 1; overflow-y: auto; padding: 4px 10px 14px; scrollbar-width: thin; scrollbar-color: #2b2e3b transparent; }
    .group-label { font-size: 12px; color: var(--muted); padding: 14px 8px 6px; }
    .cat {
      display: flex; align-items: center; gap: 10px; width: 100%;
      padding: 6px 8px; margin: 1px 0; border: 0; border-radius: 10px;
      background: transparent; color: #c5c8d6; cursor: pointer; text-align: left;
      font: inherit; font-size: 13.5px;
      transition: background .12s, color .12s;
    }
    .cat:hover { background: rgba(255,255,255,.045); color: #fff; }
    .cat.active {
      background: linear-gradient(90deg, rgba(88,101,242,.28), rgba(88,101,242,.08));
      color: #fff; box-shadow: inset 2px 0 0 var(--blurple);
    }
    .cat .ico {
      width: 34px; height: 34px; flex: none; border-radius: 9px;
      background: var(--raised); border: 1px solid var(--line);
      display: grid; place-items: center;
    }
    .cat .ico img { max-width: 26px; max-height: 26px; image-rendering: auto; }
    .cat .name { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .cat .n {
      font-size: 11.5px; color: var(--muted); background: rgba(255,255,255,.05);
      padding: 2px 7px; border-radius: 99px; font-variant-numeric: tabular-nums;
    }
    .cat.active .n { color: #fff; background: rgba(255,255,255,.14); }

    /* Main */
    .main { display: flex; flex-direction: column; min-width: 0; min-height: 0; }
    .head {
      display: flex; align-items: center; gap: 14px; padding: 18px 22px 14px;
      border-bottom: 1px solid var(--line);
      background: linear-gradient(180deg, rgba(88,101,242,.07), transparent);
    }
    .head .title { flex: 1; min-width: 0; }
    .head h2 { margin: 0; font-size: 22px; font-weight: 700; letter-spacing: .1px; }
    .head p { margin: 3px 0 0; font-size: 12.5px; color: var(--muted); }

    .search { position: relative; width: 260px; }
    .search svg { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); width: 15px; height: 15px; color: var(--muted); pointer-events: none; }
    .search input {
      width: 100%; height: 36px; padding: 0 12px 0 34px;
      background: var(--ink); color: #fff; font: inherit; font-size: 13.5px;
      border: 1px solid var(--line); border-radius: 10px; outline: none;
      transition: border-color .12s, box-shadow .12s;
    }
    .search input::placeholder { color: #666a7d; }
    .search input:focus { border-color: var(--blurple); box-shadow: 0 0 0 3px rgba(88,101,242,.22); }

    .icon-btn {
      width: 36px; height: 36px; border-radius: 10px; border: 1px solid var(--line);
      background: var(--raised); color: #c5c8d6; cursor: pointer; display: grid; place-items: center;
      transition: background .12s, color .12s, border-color .12s;
    }
    .icon-btn:hover { background: #22242e; color: #fff; border-color: #343746; }
    .icon-btn:focus-visible, .cat:focus-visible, th.sortable:focus-visible, a.link:focus-visible { outline: 2px solid var(--blurple); outline-offset: 2px; }
    .icon-btn svg { width: 16px; height: 16px; }

    .tablewrap { flex: 1; min-height: 0; overflow: auto; scrollbar-width: thin; scrollbar-color: #2b2e3b transparent; }
    table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 14px; }
    thead th {
      position: sticky; top: 0; z-index: 2; text-align: left; padding: 11px 16px;
      background: #171820; color: var(--muted); font-weight: 600; font-size: 12.5px;
      border-bottom: 1px solid var(--line); white-space: nowrap; user-select: none;
    }
    th.sortable { cursor: pointer; transition: color .12s; }
    th.sortable:hover { color: #fff; }
    th.sorted { color: #fff; }
    th .arrow { display: inline-block; width: 12px; margin-left: 5px; color: var(--amber); }
    th.num, td.num { text-align: right; }

    tbody td { padding: 8px 16px; border-bottom: 1px solid rgba(255,255,255,.04); vertical-align: middle; }
    tbody tr { transition: background .1s; }
    tbody tr:hover { background: rgba(88,101,242,.09); }
    td.thumb { width: 84px; }
    .thumb-box {
      width: 56px; height: 56px; border-radius: 12px; display: grid; place-items: center;
      background: radial-gradient(circle at 50% 35%, #262937, #171922);
      border: 1px solid var(--line);
    }
    .thumb-box img { max-width: 46px; max-height: 46px; }
    td.id { font-variant-numeric: tabular-nums; color: #c5c8d6; }
    td.id small { color: var(--muted); margin-right: 6px; }
    td.name { font-weight: 600; color: #fff; }
    td.name small { display: block; font-weight: 400; color: var(--muted); font-size: 12px; margin-top: 2px; }
    .count {
      display: inline-flex; align-items: center; gap: 6px; padding: 4px 11px; border-radius: 99px;
      background: rgba(255,160,5,.12); color: var(--amber); font-weight: 700; font-variant-numeric: tabular-nums;
      border: 1px solid rgba(255,160,5,.28);
    }
	.count.voted {
  background: rgba(255, 85, 120, .14);
  color: #ff9aae;
  border-color: rgba(255, 85, 120, .38);
  box-shadow:
    0 0 10px rgba(255, 70, 110, .10),
    inset 0 0 8px rgba(255, 140, 160, .05);
}
    .count svg { width: 13px; height: 13px; }
    a.link {
      display: inline-flex; align-items: center; gap: 6px; padding: 5px 11px; border-radius: 8px;
      color: #aeb5ff; text-decoration: none; font-size: 13px; border: 1px solid #2e3350; background: rgba(88,101,242,.1);
      transition: background .12s, color .12s;
    }
    a.link:hover { background: var(--blurple); color: #fff; }
    a.link svg { width: 12px; height: 12px; }

    .state { padding: 70px 20px; text-align: center; color: var(--muted); }
    .state b { display: block; color: #fff; font-size: 16px; margin-bottom: 6px; }
    .spinner {
      width: 30px; height: 30px; margin: 0 auto 16px; border-radius: 50%;
      border: 3px solid #2a2d3a; border-top-color: var(--blurple); animation: spin .8s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg) } }

    @media (max-width: 820px) {
      .panel { grid-template-columns: 1fr; grid-template-rows: auto 1fr; }
      .side { border-right: 0; border-bottom: 1px solid var(--line); max-height: 190px; }
      .search { width: 170px; }
    }
    @media (prefers-reduced-motion: reduce) {
      .overlay, .panel, .spinner { animation: none; }
    }
  `;

  const SVG = {
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
    star: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 2.5 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/></svg>',
    ext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
  };

  const state = {
    items: [],
    loaded: false,
    loading: false,
    category: 'All',
    search: '',
    sort: { key: 'count', dir: 'desc' },
  };

  let modalHost = null;
  let modalRoot = null;

  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    }
    for (const c of [].concat(children)) if (c) node.append(c);
    return node;
  }

  const fmt = (n) => Number(n).toLocaleString('pt-BR');
  const sameCat = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();

  function visibleItems() {
    const q = state.search.trim().toLowerCase();
    let list = state.items.filter((it) => state.category === 'All' || sameCat(it.category, state.category));
    if (q) {
      list = list.filter(
        (it) =>
          it.title.toLowerCase().includes(q) ||
          String(it.itemID).includes(q) ||
          it.category.toLowerCase().includes(q)
      );
    }

    const { key, dir } = state.sort;
    const m = dir === 'asc' ? 1 : -1;
    list.sort((a, b) => {
      if (key === 'title') return m * a.title.localeCompare(b.title, undefined, { numeric: true, sensitivity: 'base' });
      if (key === 'itemID') return m * (a.categoryID - b.categoryID || a.itemID - b.itemID);
      return m * (a.count - b.count) || a.title.localeCompare(b.title);
    });
    return list;
  }

  function setSort(key) {
    if (state.sort.key === key) {
      state.sort.dir = state.sort.dir === 'asc' ? 'desc' : 'asc';
    } else {
      state.sort = { key, dir: key === 'count' ? 'desc' : 'asc' };
    }
    renderMain();
  }

  function renderSidebar() {
    const cats = modalRoot.querySelector('.cats');
    cats.textContent = '';

    const counts = {};
    for (const it of state.items) {
      const k = it.category.toLowerCase();
      counts[k] = (counts[k] || 0) + 1;
    }

    let lastGroup = null;
    for (const c of CATEGORIES) {
      if (c.group !== lastGroup && c.group === 'objects') {
        cats.append(el('div', { class: 'group-label', text: 'Objetos de shaman' }));
      }
      lastGroup = c.group;

      const n = c.name === 'All' ? state.items.length : counts[c.name.toLowerCase()] || 0;
      const btn = el(
        'button',
        {
          class: 'cat' + (state.category === c.name ? ' active' : ''),
          type: 'button',
          onclick: () => {
            state.category = c.name;
            renderSidebar();
            renderMain();
            const tw = modalRoot.querySelector('.tablewrap');
            if (tw) tw.scrollTop = 0;
          },
        },
        [
          el('span', { class: 'ico' }, [el('img', { src: c.img, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer' })]),
          el('span', { class: 'name', text: c.name }),
          el('span', { class: 'n', text: fmt(n) }),
        ]
      );
      cats.append(btn);
    }
  }

  function renderMain() {
    const head = modalRoot.querySelector('.head');
    const body = modalRoot.querySelector('.tablewrap');
    const list = state.loaded ? visibleItems() : [];

    head.querySelector('h2').textContent = state.category;
    head.querySelector('p').textContent = state.loaded
      ? `${fmt(list.length)} ${list.length === 1 ? 'item' : 'itens'}${state.search ? ' encontrados' : ''}`
      : state.loading
      ? 'Carregando…'
      : '';

    body.textContent = '';

    if (state.loading && !state.loaded) {
      body.append(
        el('div', { class: 'state' }, [
          el('div', { class: 'spinner' }),
          el('b', { class: 'progress', text: 'Buscando mensagens…' }),
          el('span', { text: 'Isso pode levar alguns segundos.' }),
        ])
      );
      return;
    }

    if (!state.items.length) {
      body.append(
        el('div', { class: 'state' }, [
          el('b', { text: 'Nenhum item carregado' }),
          el('span', { text: 'Use o botão de atualizar para buscar as mensagens novamente.' }),
        ])
      );
      return;
    }

    if (!list.length) {
      body.append(
        el('div', { class: 'state' }, [
          el('b', { text: 'Nada encontrado' }),
          el('span', { text: state.search ? 'Tente outro termo de busca.' : 'Não há itens nesta categoria.' }),
        ])
      );
      return;
    }

    const showCat = state.category === 'All';

    const th = (label, key, cls = '') => {
      const sorted = state.sort.key === key;
      const arrow = sorted ? (state.sort.dir === 'asc' ? '▲' : '▼') : '';
      return el(
        'th',
        {
          class: `sortable ${cls} ${sorted ? 'sorted' : ''}`.trim(),
          tabindex: '0',
          role: 'button',
          'aria-sort': sorted ? (state.sort.dir === 'asc' ? 'ascending' : 'descending') : 'none',
          onclick: () => setSort(key),
          onkeydown: (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setSort(key);
            }
          },
        },
        [document.createTextNode(label), el('span', { class: 'arrow', text: arrow })]
      );
    };

    const table = el('table');
    table.append(
      el('thead', {}, [
        el('tr', {}, [
          el('th', { text: 'Imagem' }),
          th(showCat ? 'Categoria / ID' : 'ID', 'itemID'),
          th('Nome', 'title'),
          th('Votos', 'count', 'num'),
          el('th', { text: 'Mensagem' }),
        ]),
      ])
    );

    const tbody = el('tbody');
    for (const it of list) {
      const img = el('img', { src: it.img, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer' });
      const idCell = el('td', { class: 'id' });
      if (showCat) idCell.append(el('small', { text: it.category }));
      idCell.append(document.createTextNode(String(it.itemID)));

      tbody.append(
        el('tr', {}, [
          el('td', { class: 'thumb' }, [el('div', { class: 'thumb-box' }, [img])]),
          idCell,
          el('td', { class: 'name', text: it.title }),
          el('td', { class: 'num' }, [el('span', { class: 'count' + (it.voted ? ' voted' : ''), html: SVG.star + '<span>' + fmt(it.count) + '</span>' })]),
          el('td', {}, [
            el('a', {
              class: 'link',
              href: MESSAGE_URL + it.messageID,
              target: '_blank',
              rel: 'noopener noreferrer',
              html: '<span>mensagem</span>' + SVG.ext,
            }),
          ]),
        ])
      );
    }
    table.append(tbody);
    body.append(table);
  }

  async function loadData() {
    if (state.loading) return;
    state.loading = true;
    state.loaded = false;
    renderMain();

    try {
      state.items = await fetchAllItems((n) => {
        const p = modalRoot && modalRoot.querySelector('.progress');
        if (p) p.textContent = `${fmt(n)} itens encontrados…`;
      });
    } catch (err) {
      console.error('[Discord Sale] erro ao buscar mensagens:', err);
      state.items = [];
    }

    state.loading = false;
    state.loaded = true;
    if (modalRoot) {
      renderSidebar();
      renderMain();
    }
  }

  function closeModal() {
    if (modalHost) {
      modalHost.remove();
      modalHost = null;
      modalRoot = null;
    }
  }

  function openModal() {
    if (modalHost) return;

    modalHost = document.createElement('div');
    modalHost.setAttribute('data-sale-modal', '');
    modalRoot = modalHost.attachShadow({ mode: 'open' });

    const style = document.createElement('style');
    style.textContent = CSS;

    const searchInput = el('input', {
      type: 'text',
      placeholder: 'Buscar por nome ou ID',
      spellcheck: 'false',
      autocomplete: 'off',
      'aria-label': 'Buscar itens',
    });
    searchInput.addEventListener('input', () => {
      state.search = searchInput.value;
      renderMain();
    });

    const overlay = el('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Sale' }, [
      el('div', { class: 'panel' }, [
        el('aside', { class: 'side' }, [
          el('div', { class: 'brand' }, [
            el('img', { src: URL_GIF2, alt: '' }),
            el('div', {}, [el('b', { text: 'Sale' }), el('span', { text: '' })]),
          ]),
          el('div', { class: 'cats' }),
        ]),
        el('section', { class: 'main' }, [
          el('header', { class: 'head' }, [
            el('div', { class: 'title' }, [el('h2'), el('p')]),
            el('div', { class: 'search', html: SVG.search }, [searchInput]),
            el('button', { class: 'icon-btn', type: 'button', title: 'Atualizar', 'aria-label': 'Atualizar', html: SVG.refresh, onclick: loadData }),
            el('button', { class: 'icon-btn', type: 'button', title: 'Fechar', 'aria-label': 'Fechar', html: SVG.close, onclick: closeModal }),
          ]),
          el('div', { class: 'tablewrap' }),
        ]),
      ]),
    ]);

    // clicar fora do painel fecha
    overlay.addEventListener('mousedown', (e) => {
      if (e.target === overlay) closeModal();
    });

    // evita que atalhos do Discord capturem o que é digitado no modal
    modalHost.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Escape') closeModal();
    });
    modalHost.addEventListener('keyup', (e) => e.stopPropagation());
    modalHost.addEventListener('keypress', (e) => e.stopPropagation());

    modalRoot.append(style, overlay);
    document.body.append(modalHost);

    renderSidebar();
    renderMain();
    searchInput.focus();

    if (!state.loaded) loadData();
  }

  /* ------------------------------------------------------------------ *
   *  Botão na barra do chat
   * ------------------------------------------------------------------ */

  const isTargetChannel = () =>
    location.pathname.startsWith(`/channels/${GUILD_ID}/${CHANNEL_ID}`);

  function buildButton(templateButton) {
    const templateWrapper = templateButton ? templateButton.firstElementChild : null;

    const btn = document.createElement('div');
    btn.className = templateButton ? templateButton.className : '';
    btn.setAttribute(BTN_ATTR, '');
    btn.setAttribute('role', 'button');
    btn.setAttribute('tabindex', '0');
    btn.setAttribute('aria-label', 'Sale');
    btn.setAttribute('aria-haspopup', 'dialog');
    btn.style.cursor = 'pointer';

    const wrapper = document.createElement('div');
    wrapper.className = templateWrapper ? templateWrapper.className : '';
    wrapper.style.cssText = 'opacity:1;transform:none;display:flex;align-items:center;justify-content:center;';

    const img = document.createElement('img');
    img.src = URL_PNG;
    img.alt = '';
    img.draggable = false;
    img.style.cssText = 'width:24px;height:24px;object-fit:contain;display:block;';

    // pré-carrega o gif para o hover não piscar
    const preload = new Image();
    preload.src = URL_GIF;

    btn.addEventListener('mouseenter', () => (img.src = URL_GIF));
    btn.addEventListener('mouseleave', () => (img.src = URL_PNG));
    btn.addEventListener('focus', () => (img.src = URL_GIF));
    btn.addEventListener('blur', () => (img.src = URL_PNG));

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openModal();
    });
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openModal();
      }
    });

    wrapper.append(img);
    btn.append(wrapper);
    return btn;
  }

  function injectButton() {
    if (!isTargetChannel()) {
      closeModal();
      return;
    }

    const bar = document.querySelector('[class*="sansAttachButton_"]');
    if (!bar) return;

    const buttons = bar.querySelector('[class^="buttons_"], [class*=" buttons_"]');
    if (!buttons) return;

    if (buttons.querySelector(`[${BTN_ATTR}]`)) return;

    const template = buttons.querySelector('[role="button"]');
    if (!template) return; // botões ainda não renderizados

    const container = template.parentElement || buttons;
    container.prepend(buildButton(template));
  }

  // Discord é uma SPA: observa mudanças e reinjeta quando a barra for recriada
  let scheduled = false;
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      injectButton();
    });
  };

  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('popstate', schedule);
  setInterval(schedule, 1500);
  schedule();
})();
